<?php
/*
Plugin Name: CMB2 Field Type: Google Maps
Plugin URI: https://github.com/mustardBees/cmb_field_map
GitHub Plugin URI: https://github.com/mustardBees/cmb_field_map
Description: Google Maps field type for CMB2.
Version: 2.1.2
Author: Phil Wylie
Author URI: http://www.philwylie.co.uk/
License: GPLv2+
*/

/**
 * Class PW_CMB2_Field_Google_Maps
 */
class PW_CMB2_Field_Google_Maps {

	/**
	 * Current version number
	 */
	const VERSION = '2.1.2';

	/**
	 * Initialize the plugin by hooking into CMB2
	 */
	public function __construct() {
		add_filter( 'cmb2_render_pw_map', array( $this, 'render_pw_map' ), 10, 5 );
		add_filter( 'cmb2_sanitize_pw_map', array( $this, 'sanitize_pw_map' ), 10, 4 );
	}

	/**
	 * Render field
	 */
	public function render_pw_map( $field, $field_escaped_value, $field_object_id, $field_object_type, $field_type_object ) {
		$this->setup_admin_scripts();

		echo '<input type="text" class="large-text pw-map-search" id="' . $field->args( 'id' ) . '" />';

		echo '<div class="pw-map"></div>';

		$field_type_object->_desc( true, true );

		echo $field_type_object->input( array(
			'type'       => 'hidden',
			'name'       => $field->args('_name') . '[latitude]',
			'value'      => isset( $field_escaped_value['latitude'] ) ? $field_escaped_value['latitude'] : '',
			'class'      => 'pw-map-latitude',
			'desc'       => '',
		) );
		echo $field_type_object->input( array(
			'type'       => 'hidden',
			'name'       => $field->args('_name') . '[longitude]',
			'value'      => isset( $field_escaped_value['longitude'] ) ? $field_escaped_value['longitude'] : '',
			'class'      => 'pw-map-longitude',
			'desc'       => '',
		) );
		echo $field_type_object->input( array(
			'type'       => 'hidden',
			'name'       => $field->args('_name') . '[zoom]',
			'value'      => isset( $field_escaped_value['zoom'] ) ? $field_escaped_value['zoom'] : '',
			'class'      => 'pw-map-zoom',
			'desc'       => '',
		) );
	}

	/**
	 * Optionally save the latitude/longitude values into two custom fields
	 */
	public function sanitize_pw_map( $override_value, $value, $object_id, $field_args ) {
		if ( isset( $field_args['split_values'] ) && $field_args['split_values'] ) {
			if ( ! empty( $value['latitude'] ) ) {
				update_post_meta( $object_id, $field_args['id'] . '_latitude', $value['latitude'] );
			}

			if ( ! empty( $value['longitude'] ) ) {
				update_post_meta( $object_id, $field_args['id'] . '_longitude', $value['longitude'] );
			}

			if ( ! empty( $value['zoom'] ) ) {
				update_post_meta( $object_id, $field_args['id'] . '_zoom', $value['zoom'] );
			}else{
				//update_post_meta( $object_id, $field_args['id'] . '_zoom', 0 );
			}
		}

		return $value;
	}

	/**
	 * Enqueue scripts and styles
	 */
	public function setup_admin_scripts() {
		$api_url = '//maps.googleapis.com/maps/api/js?sensor=false&libraries=places';
        $api_key = apply_filters( 'pw-google-maps-api-key', '' );
        if ( ! empty( $api_key ) ) {
            $api_url .= '&key=' . $api_key;
        }
		wp_register_script( 'pw-google-maps-api', $api_url, null, null );
		wp_enqueue_script( 'pw-google-maps', plugins_url( 'js/script.js', __FILE__ ), array( 'pw-google-maps-api' ), self::VERSION );



		$wyz_business_form_data = get_option( 'wyz_business_form_builder_data', array() );

		//Custom form fields
		$hide_poi='no';
		if ( ! empty( $wyz_business_form_data ) && is_array( $wyz_business_form_data ) ) {
			foreach ( $wyz_business_form_data as $key => $value ) {
				if ( 'map' == $value['type'] ){
					$hide_poi = isset( $value['poi'] ) && ! empty( $value['poi'] ) ? 'yes' : 'no';
					break;
				}
			}
		}


		wp_localize_script( 'pw-google-maps', 'cmb2Map', array('hidePOI' => $hide_poi) );

		wp_enqueue_style( 'pw-google-maps', plugins_url( 'css/style.css', __FILE__ ), array(), self::VERSION );
	}
}
$pw_cmb2_field_google_maps = new PW_CMB2_Field_Google_Maps();