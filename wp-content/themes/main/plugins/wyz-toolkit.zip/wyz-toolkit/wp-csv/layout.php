<div id='wpcsv'>
<div id='cpk_wpcsv_header'>
</div>
<div id='cpk_wpcsv_content'>
<div id='cpk_wpcsv_left'>
<?php require_once( $inner_page ); ?>
</div>
<?php require_once( $sidebar_page ); ?>
</div>
<div id='cpk_wpcsv_footer'>
</div>
</div>
