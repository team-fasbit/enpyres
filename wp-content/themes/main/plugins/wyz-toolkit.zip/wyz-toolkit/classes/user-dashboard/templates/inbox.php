<div class="row-fluid">		
	<div class="span12">
		<?php echo do_shortcode('[private_message_user_inbox]');?>
	</div>
</div>