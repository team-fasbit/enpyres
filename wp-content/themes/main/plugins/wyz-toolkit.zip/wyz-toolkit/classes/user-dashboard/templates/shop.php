<div class="row-fluid">		
	<div class="span12">
		<?php echo do_shortcode( '[woocommerce_my_account]' );?>
	</div>
</div>