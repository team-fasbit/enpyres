<div class="row-fluid">		
	<div class="span12">
		<?php echo do_shortcode( '[booked-profile]' );?>
	</div>
</div>