<?php

/**
 * The following are demo functionalities which you can use to override certain theme functionalities
 * Note that this file is up for modifications with each theme update.
 */

/**
 * Overriding Wyzi Helper functions
 */
/*create a file containing a php class named: WyzHelpersOverride
inside, create  functions with same header as the ones intended for override from the WyzHelpers class
WyzHelpers class is located in wyz-toolkit/classes/helpers.php */
//require_once(get_stylesheet_directory() . '/classes/helpers-override.php');



/**
 * Overriding Wyzi Business Post Class functions
 */
/*create a file containing a php class named: WyzBusinessPostOverride
inside, create  functions with same header as the ones intended for override from the WyzBusinessPos class
WyzBusinessPost class is located in wyz-toolkit\businesses-and-offers\businesses\business-post.php */
//require_once(get_stylesheet_directory() . '/classes/business-post-override.php');


/* Rest of theme functions go here */