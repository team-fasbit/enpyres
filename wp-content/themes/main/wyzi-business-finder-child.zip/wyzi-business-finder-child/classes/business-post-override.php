<?php
class WyzBusinessPostOverride
{
	/**    functions overrides here     **/

	//example:
	/*public static function wyz_create_post( $value, $is_current_user_author = false, $is_wall = false ) {
		whatever is written here will override the function displaying the business posts in the wall and business wall
	}*/
}
