<?php
class WyzHelpersOverride
{
	/**    functions overrides here     **/

	//example:
	/*public static function the_business_sidebar( $id ) {
		whatever is written here will override the function displaying the business sidebar
	}*/
}
